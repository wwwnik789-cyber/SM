SM Production — последние 4 визуализации фотопропсов

1. sm-fp5-croissant-pvc.jpg — гигантский круассан
2. sm-fp5-coffee-cup-pvc.jpg — стаканчик кофе с брендингом
3. sm-fp5-glasses-pvc.jpg — гигантские очки
4. sm-fp5-lips-pvc.jpg — гигантские губы

Формат: JPG, 1200 × 672 px.
Концепция: ПВХ 8–10 мм, без деревянных держателей.
